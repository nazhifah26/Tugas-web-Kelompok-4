<?php

namespace App\Models;

use CodeIgniter\Model;

class RumahModel extends Model
{
    protected $table = 'rumah';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nama', 'lokasi', 'harga', 'gambar', 'deskripsi'];
}
